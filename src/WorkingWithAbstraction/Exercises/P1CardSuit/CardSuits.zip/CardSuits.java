package WorkingWithAbstraction.Exercises.P1CardSuit;

public enum CardSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;

}
