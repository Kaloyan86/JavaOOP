package WorkingWithAbstraction.Exercises.P4TrafficLights;

public enum LightStates {

    RED,
    GREEN,
    YELLOW,


}
